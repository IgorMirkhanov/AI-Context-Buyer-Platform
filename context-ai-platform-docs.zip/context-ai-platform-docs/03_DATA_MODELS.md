# Модели данных

## 1. Основные таблицы (Postgres, упрощённо)

```sql
-- Пользователи и организации (агентства могут вести много проектов)
organizations (id, name, plan, created_at)
users (id, organization_id, email, role, created_at)

-- Проекты — единица изоляции для клиента/аккаунта
projects (
  id, organization_id, name, status,
  primary_platform,        -- 'yandex_direct' | 'google_ads'
  website_url, created_at, updated_at
)

-- OAuth-доступы, привязанные к проекту и платформе
ad_platform_credentials (
  id, project_id, platform,           -- 'yandex_direct' | 'google_ads'
  access_token_encrypted, refresh_token_encrypted,
  expires_at, scopes, external_account_id, created_at
)

-- Бриф проекта (структурированный JSON, схема ниже)
project_briefs (id, project_id, version, payload_json, created_at)

-- Семантическое ядро
semantic_keywords (
  id, project_id, phrase, frequency, intent,  -- hot|warm|navigational
  cluster_id, is_negative, source, created_at
)
semantic_clusters (id, project_id, name, category, created_at)

-- Рекламные креативы
ad_creatives (
  id, project_id, cluster_id, type,   -- headline|description|sitelink|callout
  text, status, ab_group, created_at
)

-- Черновики и реальные кампании
campaign_drafts (id, project_id, structure_json, status, created_at)
campaigns (
  id, project_id, external_campaign_id, platform,
  status, budget, targeting_json, created_at
)

-- Задачи оркестратора
agent_tasks (
  id, project_id, agent_type, status,   -- pending|running|done|failed
  input_ref, output_ref, error, started_at, finished_at
)

-- Метрики (снимки статистики по дням)
performance_snapshots (
  id, project_id, campaign_id, date,
  impressions, clicks, ctr, cpc, conversions, cpl, spend
)
```

## 2. JSON-схема брифа проекта (`project_briefs.payload_json`)

```json
{
  "project": {
    "website_url": "https://example.com",
    "geo": ["RU-MOW", "KZ-ALA"],
    "budget": { "daily": 5000, "currency": "RUB" },
    "target_cpl": 300,
    "platforms": ["yandex_direct"]
  },
  "marketing": {
    "product_description": "Продажа игровых ноутбуков премиум-сегмента",
    "usp": [
      "Гарантия 3 года",
      "Бесплатная доставка по РФ",
      "Trade-in старого устройства"
    ],
    "target_audience": [
      {
        "segment": "Геймеры 18-30",
        "pains": ["нужна высокая производительность", "боятся перегрева"],
        "objections": ["дорого", "не уверены в надёжности бренда"]
      }
    ],
    "forbidden_phrases": ["самый дешёвый", "гарантия 100%"],
    "price_segment": "premium"
  },
  "exclusions": {
    "global_negative_keywords": ["бесплатно", "скачать", "торрент", "б/у", "ремонт"],
    "excluded_placements": ["example-junk-site.ru"]
  },
  "utm": {
    "template": "utm_source={platform}&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}"
  },
  "goals": [
    { "name": "Заявка на сайте", "type": "form_submit", "external_goal_id": "12345" },
    { "name": "Звонок", "type": "call", "external_goal_id": "67890" }
  ]
}
```

## 3. Внутреннее представление семантического ядра (между агентами)

```json
{
  "clusters": [
    {
      "cluster_name": "Игровые ноутбуки Asus",
      "category": "brand",
      "keywords": [
        { "phrase": "купить игровой ноутбук asus", "intent": "hot", "frequency": 1200 },
        { "phrase": "ноутбук asus rog обзор", "intent": "warm", "frequency": 300 }
      ],
      "negative_keywords": ["ремонт asus", "asus драйвера"]
    }
  ],
  "global_negatives": ["бесплатно", "скачать", "б/у"]
}
```

## 4. Внутреннее представление рекламных креативов

```json
{
  "cluster_name": "Игровые ноутбуки Asus",
  "ads": [
    {
      "headline1": "Игровые ноутбуки Asus ROG",
      "headline2": "Гарантия 3 года | Доставка бесплатно",
      "description": "Официальный магазин. Trade-in старого устройства. Выбор из 40+ моделей.",
      "sitelinks": ["Каталог ROG", "Рассрочка 0%", "Сравнить модели", "Контакты"],
      "callouts": ["Гарантия 3 года", "Бесплатная доставка", "Trade-in"]
    }
  ],
  "ab_variants": 2
}
```

## 5. Единый внутренний формат структуры кампании (перед пушем в API платформы)

```json
{
  "campaign": {
    "name": "Asus Gaming — Search — RU",
    "type": "search",
    "budget_daily": 5000,
    "bidding_strategy": "manual_cpc",
    "geo": ["RU-MOW"],
    "schedule": { "days": ["mon-fri"], "hours": "08:00-22:00" }
  },
  "ad_groups": [
    {
      "name": "Игровые ноутбуки Asus",
      "keywords": ["купить игровой ноутбук asus"],
      "negative_keywords": ["ремонт asus"],
      "ads": ["<ссылка на ad_creatives по id>"]
    }
  ]
}
```

Этот единый формат — точка контракта между `Campaign Builder Agent` и
`Connector Layer`: конвертацию в специфичный формат Яндекс Директа или
Google Ads делает адаптер, а не агент.
